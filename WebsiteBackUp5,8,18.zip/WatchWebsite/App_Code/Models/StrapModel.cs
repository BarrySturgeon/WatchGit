﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for StrapModel
/// </summary>
public class StrapModel
{
    public StrapModel()
    {
        //
        // TODO: Add constructor logic here
        //
    }
}